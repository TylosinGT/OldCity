﻿namespace StumpMirrorTest
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.tylosingt.gorillatag.oldcity";
        public const string Name = "OldCity";
        public const string Version = "1.0.0";
    }
}
